﻿' Copyright 2011 Branden Coates

' Licensed under the Apache License, Version 2.0 (the "License");
' you may not use this file except in compliance with the License.
' You may obtain a copy of the License at

' http://www.apache.org/licenses/LICENSE-2.0

' Unless required by applicable law or agreed to in writing, software
' distributed under the License is distributed on an "AS IS" BASIS,
' WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
' See the License for the specific language governing permissions and
' limitations under the License.

' Contact:    Branden Coates
'             branden.c.coates@gmail.com

Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("COMRedirSVC")> 
<Assembly: AssemblyDescription("COM1 to CMD Redirector")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("COMRedirSVC")> 
<Assembly: AssemblyCopyright("Copyright Branden Coates 2011")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4e091fad-857b-47aa-b5bd-774c75fbaa24")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.2.0.0")> 
<Assembly: AssemblyFileVersion("1.2.0.0")> 

<Assembly: NeutralResourcesLanguageAttribute("")> 